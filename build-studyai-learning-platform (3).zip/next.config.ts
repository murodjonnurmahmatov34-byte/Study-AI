import type { NextConfig } from "next";

/**
 * StudyAI — Next.js configuration.
 *
 * Project root: the repository root (where this file and package.json live).
 * App Router:   src/app  (auto-detected by Next.js; no `appDir` flag needed).
 *
 * On Vercel the "Root Directory" project setting MUST be left empty so the
 * build runs from this folder.
 */
const nextConfig: NextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
};

export default nextConfig;
