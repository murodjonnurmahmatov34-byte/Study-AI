# StudyAI — Learn Smarter with AI

A production-ready, AI-powered personal learning platform for students: AI tutor chat, smart summarizer, AI quiz generator, study notes, study materials library, real progress analytics, and full account management — built on **Next.js (App Router) + TypeScript + Tailwind CSS v4 + PostgreSQL (Drizzle ORM)**.

## Features

- **Landing page** — full SaaS marketing site (features, how it works, testimonials, pricing, FAQ, about, final CTA).
- **Authentication** — email/password registration, login, logout, forgot-password flow. Scrypt password hashing (per-user salt), signed HttpOnly session cookies, 30-day server-side sessions, per-user data isolation, protected routes & API guards, rate limiting on auth and AI endpoints.
- **Dashboard** — welcome, real DB-driven stats (sessions, topics, quizzes, average score, streak), weekly activity chart, weekly goal donut, recent activity, recommended topics, quick actions.
- **AI Tutor** — persistent conversations (saved to DB), markdown answers, typing state, error state, delete/clear conversation, honest "I don't know" behavior, offline-mode transparency.
- **Summarizer** — length/difficulty/style controls → summary + key points + concepts + keywords; copy, save, regenerate; saved summaries library with delete.
- **Quiz Generator** — topic + optional material, question count/difficulty/type (MC or T/F); full quiz player with progress; auto-graded attempts with per-answer explanations; quiz library (retake) + attempt history.
- **Notes & Study Materials** — full CRUD, search, subject filter, sort, tags, confirm-on-delete, empty states.
- **Progress** — real statistics: weekly & monthly activity, quiz performance trend, activity mix, subject coverage, streaks.
- **Settings** — profile (name/email/avatar color), preferences (theme, notifications, weekly goal, difficulty), change password, logout, delete account (type-to-confirm).
- **Global search** (topbar) across notes, materials, summaries, quizzes, conversations; **notifications** dropdown fed by real activity.

## AI architecture (no client-side secrets)

All AI calls happen in **server-side route handlers** via `src/lib/ai.ts`:

| Env var | Purpose |
| --- | --- |
| `AI_API_KEY` | API key for any OpenAI-compatible provider (server-side only) |
| `AI_BASE_URL` | Optional; default `https://api.openai.com/v1` |
| `AI_MODEL` | Optional; default `gpt-4o-mini` |

If no key is configured, the app **still works end-to-end** with a built-in offline engine (`src/lib/ai-local.ts`): extractive summarization, material-based quiz generation, and an honest offline tutor mode. The UI clearly labels results as "AI generated" vs "Offline engine".

## Getting started

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env   # then fill in real values

# 3. Create the schema (Drizzle)
npx drizzle-kit push

# 4. Run
npm run dev            # development
npm run build && npm start  # production
```

## Deploying to Vercel

The Next.js App Router lives in **`src/app`** (auto-detected by Next.js — no `appDir` config needed). `package.json`, `next.config.ts`, and `tsconfig.json` are at the repository root.

1. Import the repository in Vercel. Framework preset: **Next.js** (`vercel.json` pins this).
2. **Root Directory** (Project → Settings → General): leave **empty** (repository root). This must be the folder that contains `package.json` and `src/` — **do not** set it to `src`.
   > If you see `Couldn't find any 'pages' or 'app' directory`, the build is running from the wrong folder. Causes: (a) Root Directory points at a subfolder, (b) `src/app` was not committed, or (c) a stray nested project root exists (e.g. `src/tsconfig.json` / `src/package.json`), which makes tooling treat `src/` as the project. There must be exactly **one** `package.json` and **one** `tsconfig.json`, both at the repository root — `.gitignore` now blocks nested ones. Confirm with `git ls-files src/app | wc -l` (> 0) and `git ls-files | grep -c 'src/tsconfig.json'` (must be 0), then redeploy.
3. Add environment variables (Production + Preview): `DATABASE_URL`, `AUTH_SECRET`, and optionally `AI_API_KEY`, `AI_BASE_URL`, `AI_MODEL`, `EMAIL_API_KEY`, `NEXT_PUBLIC_APP_URL`.
4. Apply the schema once: `DATABASE_URL="…" npx drizzle-kit push`
5. Deploy and verify `https://<app>/api/health` → `{"ok":true}`.

## Environment variables

See [`.env.example`](./.env.example). Required: `DATABASE_URL`, `AUTH_SECRET` (production). Optional: `AI_API_KEY`, `AI_BASE_URL`, `AI_MODEL`, `EMAIL_API_KEY`, `NEXT_PUBLIC_APP_URL`.

## Project structure

```
src/
├── app/
│   ├── page.tsx                  # landing
│   ├── (auth)/                   # login / register / forgot-password
│   ├── dashboard/                # protected workspace
│   │   ├── page.tsx              # overview (server component, real stats)
│   │   ├── tutor/ summarizer/ quiz/ notes/ materials/ progress/ settings/
│   │   └── layout.tsx            # session guard + shell
│   └── api/                      # auth, ai (chat/summarize/quiz), notes,
│                                 # materials, quizzes, summaries, stats, search,
│                                 # settings, account
├── components/                   # ui primitives, icons, charts, toasts, shell
├── db/                           # drizzle client + schema
└── lib/                          # auth, ai, ai-local (offline engine), stats,
                                  # ratelimit, api helpers, utils
```

## Security notes

- Passwords hashed with Node `scrypt` + per-user 16-byte salt, verified with `timingSafeEqual`.
- Session cookies: random 32-byte token, HMAC-signed with `AUTH_SECRET`, HttpOnly, SameSite=Lax, Secure in production, 30-day expiry, destroyable server-side.
- Every API route requires a valid session (`requireUser()`) and **scopes all queries to the authenticated user's id** — users can never read or modify another user's data.
- All inputs validated/sanitized server-side; AI output parsed and shape-checked before storage.
- Rate limiting: auth (per IP) and AI operations (per user, sliding window).
- Generic errors returned for auth failures; internal errors logged server-side only.

## Data model

`users`, `sessions`, `user_preferences`, `conversations`, `messages`, `summaries`, `notes`, `study_materials`, `quizzes`, `quiz_attempts`, `study_sessions` — all user-owned tables carry `userId` foreign keys with cascade deletes, so deleting an account removes everything.
