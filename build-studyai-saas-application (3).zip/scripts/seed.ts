/* Development seed: creates a demo account with realistic study data.
   Run: npx tsx scripts/seed.ts  (or `npm run db:seed`) */
import "dotenv/config";
import { Pool } from "pg";
import { drizzle } from "drizzle-orm/node-postgres";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import * as schema from "../src/db/schema";

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool, { schema });

const NOTES = [
  {
    subject: "Biology",
    title: "Photosynthesis — Light and Dark Reactions",
    content: `Photosynthesis is the process by which green plants, algae and some bacteria convert light energy into chemical energy stored in glucose. The overall equation is 6CO2 + 6H2O + light energy → C6H12O6 + 6O2. Photosynthesis takes place in the chloroplast, an organelle that contains the green pigment chlorophyll.

The light-dependent reactions occur in the thylakoid membranes of the chloroplast. Chlorophyll absorbs light energy, which excites electrons and drives the splitting of water molecules in a process called photolysis. Photolysis releases oxygen as a by-product. The energy captured is used to produce ATP and NADPH, two energy carriers that power the next stage.

The light-independent reactions, also known as the Calvin cycle, occur in the stroma of the chloroplast. The Calvin cycle uses ATP and NADPH to fix carbon dioxide into a three-carbon sugar called glyceraldehyde-3-phosphate. The enzyme RuBisCO catalyses the first step of carbon fixation by attaching CO2 to ribulose bisphosphate. Glyceraldehyde-3-phosphate is later used to build glucose and other carbohydrates.

Several factors limit the rate of photosynthesis. Light intensity, carbon dioxide concentration and temperature are the three main limiting factors. At low light intensity the light-dependent reactions are the bottleneck. At very high temperatures enzymes such as RuBisCO denature and the rate falls sharply.

Photosynthesis is essential for life on Earth because it produces the oxygen we breathe and forms the base of nearly every food chain.`,
  },
  {
    subject: "History",
    title: "Causes of the French Revolution",
    content: `The French Revolution began in 1789 and transformed France from an absolute monarchy into a republic. Historians identify three main causes of the French Revolution: financial crisis, social inequality, and Enlightenment ideas.

The financial crisis was severe. France was nearly bankrupt after supporting the American Revolution and decades of expensive wars. King Louis XVI attempted to raise taxes, but the nobility resisted reform. Poor harvests in 1788 caused bread prices to soar, and many ordinary people faced starvation.

Social inequality was built into the Estates System. French society was divided into three estates. The First Estate was the clergy, the Second Estate was the nobility, and the Third Estate was everyone else, about 97 percent of the population. The first two estates paid almost no taxes while the Third Estate carried the tax burden.

Enlightenment ideas spread widely in the eighteenth century. Philosophers such as Voltaire, Rousseau and Montesquieu criticised absolute monarchy and argued for liberty, equality and popular sovereignty. These ideas inspired the Third Estate to demand political representation.

The revolution was triggered when the Third Estate declared itself the National Assembly in June 1789 and took the Tennis Court Oath, vowing not to disband until France had a constitution. On 14 July 1789 crowds stormed the Bastille, a royal fortress and prison in Paris, which became a symbol of the revolution.`,
  },
  {
    subject: "Computer Science",
    title: "Big-O Notation and Algorithm Complexity",
    content: `Big-O notation describes the upper bound of an algorithm's running time as the input size grows. Big-O notation focuses on the dominant term and ignores constant factors. It allows programmers to compare algorithms independently of hardware.

Constant time is written as O(1) and means the running time does not depend on input size. Accessing an array element by index is an O(1) operation. Logarithmic time is written as O(log n). Binary search is a classic O(log n) algorithm because it halves the search space at every step.

Linear time is written as O(n). A simple loop that visits every element once runs in linear time. Linearithmic time is written as O(n log n). Merge sort and heap sort run in O(n log n) time in all cases. Quadratic time is written as O(n^2). Bubble sort and insertion sort have quadratic worst-case complexity because of their nested loops.

Exponential time is written as O(2^n) and appears in brute-force solutions to problems such as the travelling salesman problem. Exponential algorithms become impractical even for modest input sizes.

Space complexity measures how much additional memory an algorithm uses. Merge sort requires O(n) extra space, whereas quicksort sorts in place with O(log n) stack space. Choosing an algorithm often means balancing time complexity against space complexity.`,
  },
];

async function main() {
  const email = "demo@studyai.app";
  const [existing] = await db.select().from(schema.users).where(eq(schema.users.email, email));
  if (existing) {
    await db.delete(schema.users).where(eq(schema.users.id, existing.id));
    console.log("Removed existing demo user");
  }
  const [user] = await db
    .insert(schema.users)
    .values({ name: "Demo Student", email, passwordHash: await bcrypt.hash("demo1234", 12) })
    .returning();

  const subjectRows = await db
    .insert(schema.subjects)
    .values([
      { userId: user.id, name: "Biology", color: "#10b981" },
      { userId: user.id, name: "History", color: "#f59e0b" },
      { userId: user.id, name: "Computer Science", color: "#6366f1" },
    ])
    .returning();
  const subjectId = (name: string) => subjectRows.find((s) => s.name === name)!.id;

  // Local extractive engine for seed so it works without an API key
  const { generateSummary, generateQuiz, generateFlashcards } = await import("../src/lib/ai");

  const day = (n: number) => new Date(Date.now() - n * 86400000);

  for (const [i, n] of NOTES.entries()) {
    const summary = await generateSummary(n.content);
    const [note] = await db
      .insert(schema.notes)
      .values({
        userId: user.id,
        subjectId: subjectId(n.subject),
        title: n.title,
        content: n.content,
        sourceType: i === 0 ? "pdf" : i === 1 ? "docx" : "manual",
        fileName: i === 0 ? "photosynthesis.pdf" : i === 1 ? "french-revolution.docx" : null,
        wordCount: n.content.split(/\s+/).length,
        summary: summary.summary,
        keyPoints: summary.keyPoints,
        keyTerms: summary.keyTerms,
        processingStatus: "ready",
        createdAt: day(6 - i * 2),
        updatedAt: day(6 - i * 2),
      })
      .returning();

    // Quiz + attempt
    const qs = await generateQuiz(n.content, { count: 5, difficulty: "medium", type: "mixed" });
    const [quiz] = await db
      .insert(schema.quizzes)
      .values({ userId: user.id, noteId: note.id, title: `${n.title} — medium quiz`, difficulty: "medium", questionType: "mixed", questionCount: qs.length, createdAt: day(5 - i * 2) })
      .returning();
    const inserted = await db
      .insert(schema.questions)
      .values(qs.map((q, idx) => ({ quizId: quiz.id, order: idx, type: q.type, question: q.question, options: q.options, correctAnswer: q.correctAnswer, explanation: q.explanation })))
      .returning();
    const answers = inserted.map((q, idx) => ({ questionId: q.id, answer: idx % 4 === 3 ? q.options.find((o) => o !== q.correctAnswer) ?? q.correctAnswer : q.correctAnswer }));
    const graded = answers.map((a, idx) => ({ ...a, correct: a.answer === inserted[idx].correctAnswer }));
    const score = graded.filter((g) => g.correct).length;
    await db.insert(schema.quizAttempts).values({ userId: user.id, quizId: quiz.id, score, total: inserted.length, percentage: Math.round((score / inserted.length) * 1000) / 10, timeTakenSeconds: 120 + i * 40, answers: graded, completedAt: day(5 - i * 2) });
    await db.insert(schema.studySessions).values({ userId: user.id, type: "quiz", durationSeconds: 120 + i * 40, itemsCount: inserted.length, noteId: note.id, createdAt: day(5 - i * 2) });

    // Flashcards + progress
    const cards = await generateFlashcards(n.content, 8);
    const fc = await db.insert(schema.flashcards).values(cards.map((c, idx) => ({ userId: user.id, noteId: note.id, front: c.front, back: c.back, order: idx }))).returning();
    await db.insert(schema.flashcardProgress).values(
      fc.slice(0, 5).map((c, idx) => ({ userId: user.id, flashcardId: c.id, status: idx < 3 ? "known" : "practice", reviewCount: 1 + (idx % 3), lastReviewedAt: day(4 - i) })),
    );
    await db.insert(schema.studySessions).values({ userId: user.id, type: "flashcards", durationSeconds: 75, itemsCount: 5, noteId: note.id, createdAt: day(4 - i) });
    await db.insert(schema.studySessions).values({ userId: user.id, type: "upload", durationSeconds: 0, itemsCount: 1, noteId: note.id, createdAt: day(6 - i * 2) });

    // A chat
    if (i === 1) {
      const [chat] = await db.insert(schema.chats).values({ userId: user.id, noteId: note.id, title: "What are the three main causes?", createdAt: day(1), updatedAt: day(1) }).returning();
      await db.insert(schema.chatMessages).values([
        { chatId: chat.id, role: "user", content: "What are the three main causes mentioned in this note?", createdAt: day(1) },
        { chatId: chat.id, role: "assistant", content: "According to your uploaded material, the three main causes of the French Revolution are:\n\n• **Financial crisis** — France was nearly bankrupt after supporting the American Revolution and decades of expensive wars.\n• **Social inequality** — the Estates System placed the tax burden on the Third Estate while the clergy and nobility paid almost nothing.\n• **Enlightenment ideas** — philosophers such as Voltaire, Rousseau and Montesquieu argued for liberty, equality and popular sovereignty.", createdAt: day(1) },
      ]);
      await db.insert(schema.studySessions).values({ userId: user.id, type: "chat", durationSeconds: 45, itemsCount: 1, noteId: note.id, createdAt: day(1) });
    }
  }

  const today = new Date().toISOString().slice(0, 10);
  await db.insert(schema.userProgress).values({
    userId: user.id,
    currentStreak: 4,
    longestStreak: 9,
    lastActiveDate: today,
    totalStudySeconds: 120 + 160 + 200 + 75 * 3 + 45,
    totalQuestionsAnswered: 15,
    totalCorrectAnswers: 12,
    totalFlashcardsReviewed: 15,
  });
  await db.insert(schema.studySessions).values({ userId: user.id, type: "reading", durationSeconds: 300, itemsCount: 1, createdAt: new Date() });

  console.log("Seeded demo user → demo@studyai.app / demo1234");
  await pool.end();
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
